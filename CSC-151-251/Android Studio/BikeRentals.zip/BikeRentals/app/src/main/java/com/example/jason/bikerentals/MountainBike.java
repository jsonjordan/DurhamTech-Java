package com.example.jason.bikerentals;

import android.os.Bundle;
import android.app.Activity;

public class MountainBike extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mountain_bike);
    }

}
